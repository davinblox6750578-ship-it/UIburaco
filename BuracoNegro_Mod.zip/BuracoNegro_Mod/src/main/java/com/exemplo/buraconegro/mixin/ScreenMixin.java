package com.exemplo.buraconegro.mixin;

import com.exemplo.buraconegro.BlackHoleRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Screen.class)
public abstract class ScreenMixin {
    @Shadow public int width;
    @Shadow public int height;

    // Desenha logo depois do fundo (panorama) e antes dos botões.
    @Inject(method = "renderBackground", at = @At("TAIL"))
    private void buraconegro$draw(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if ((Object) this instanceof TitleScreen) {
            BlackHoleRenderer.render(context, this.width, this.height);
        }
    }
}
