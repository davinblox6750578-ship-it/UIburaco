package com.exemplo.buraconegro.mixin;

import net.minecraft.client.gui.DrawContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * O título dos menus (Baú, Inventário...) é desenhado em cinza escuro (#404040).
 * Em fundo escuro ficaria ilegível, então trocamos por cinza claro.
 * require = 0: se a assinatura mudar, o jogo não quebra, só não aplica.
 */
@Mixin(DrawContext.class)
public abstract class DrawContextMixin {
    @ModifyVariable(method = "drawText", at = @At("HEAD"), argsOnly = true, ordinal = 2, require = 0)
    private int buraconegro$lightenDarkText(int color) {
        return (color & 0xFFFFFF) == 0x404040 ? 0xFFDDDDDD : color;
    }
}
