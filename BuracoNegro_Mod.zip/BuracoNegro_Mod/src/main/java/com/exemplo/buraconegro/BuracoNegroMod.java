package com.exemplo.buraconegro;

import net.fabricmc.api.ClientModInitializer;

public class BuracoNegroMod implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Toda a lógica está no mixin + BlackHoleRenderer.
    }
}
