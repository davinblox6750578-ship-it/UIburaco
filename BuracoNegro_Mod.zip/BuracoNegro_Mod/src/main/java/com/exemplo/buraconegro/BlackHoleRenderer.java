package com.exemplo.buraconegro;

import java.util.Random;

import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

/**
 * Fundo de tela cheia: buraco negro pré-renderizado com ray tracing
 * (lente gravitacional + efeito Doppler). O gás do disco gira em 24 quadros
 * (folha 4x6, 480x270 cada, em loop). Em jogo só troca o recorte da textura:
 * 1 quad por frame, mais zoom/movimento lento e estrelas piscando.
 */
public final class BlackHoleRenderer {
    private static final Identifier TEX = Identifier.of("buraconegro", "textures/gui/blackhole.png");

    private static final int FRAME_W = 480;
    private static final int FRAME_H = 270;
    private static final int COLS = 4;
    private static final int FRAMES = 24;
    private static final int SHEET_W = FRAME_W * COLS;
    private static final int SHEET_H = FRAME_H * 6;

    private static final float FPS = 12f;           // velocidade do giro (menor = mais lento)
    private static final float PERIOD_MS = 24000f;  // ciclo do zoom/movimento
    private static final float TAU = (float) (Math.PI * 2);

    private static final int STARS = 30;
    private static final float[] SX = new float[STARS];
    private static final float[] SY = new float[STARS];
    private static final float[] SP = new float[STARS];

    static {
        Random r = new Random(1234);
        for (int i = 0; i < STARS; i++) {
            SX[i] = r.nextFloat();
            SY[i] = r.nextFloat();
            SP[i] = r.nextFloat() * TAU;
        }
    }

    private BlackHoleRenderer() {}

    public static void render(DrawContext ctx, int w, int h) {
        long t = System.currentTimeMillis();
        float ph = (t % (long) PERIOD_MS) / PERIOD_MS * TAU;

        int frame = (int) (t * FPS / 1000f) % FRAMES;
        float u = (frame % COLS) * FRAME_W;
        float v = (frame / COLS) * FRAME_H;

        float cover = Math.max(w / (float) FRAME_W, h / (float) FRAME_H);
        float zoom = 1.08f + 0.04f * (float) Math.sin(ph);
        float dx = 0.012f * w * (float) Math.sin(ph + 1.3f);
        float dy = 0.012f * h * (float) Math.sin(ph + 0.4f);
        float s = cover * zoom;

        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(w * 0.5f + dx, h * 0.5f + dy);
        ctx.getMatrices().scale(s, s);
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, TEX,
                -FRAME_W / 2, -FRAME_H / 2, u, v,
                FRAME_W, FRAME_H, SHEET_W, SHEET_H);
        ctx.getMatrices().popMatrix();

        for (int i = 0; i < STARS; i++) {
            int a = 60 + (int) (110 * (0.5 + 0.5 * Math.sin(t / 700.0 + SP[i])));
            int x = (int) (SX[i] * w);
            int y = (int) (SY[i] * h);
            ctx.fill(x, y, x + 1, y + 1, (a << 24) | 0xFFFFFF);
        }
    }
}
